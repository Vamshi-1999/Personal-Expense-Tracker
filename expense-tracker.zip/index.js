
const express = require('express');
const app = express();
app.use(express.json());

let transactions = []; // Temporary in-memory storage

// POST /transactions - Add a new transaction
app.post('/transactions', (req, res) => {
  const { type, category, amount, date, description } = req.body;
  const newTransaction = { id: transactions.length + 1, type, category, amount, date, description };
  transactions.push(newTransaction);
  res.status(201).json(newTransaction);
});

// GET /transactions - Get all transactions
app.get('/transactions', (req, res) => {
  res.json(transactions);
});

// GET /transactions/:id - Get transaction by ID
app.get('/transactions/:id', (req, res) => {
  const transaction = transactions.find(t => t.id === parseInt(req.params.id));
  if (!transaction) return res.status(404).send('Transaction not found.');
  res.json(transaction);
});

// PUT /transactions/:id - Update a transaction by ID
app.put('/transactions/:id', (req, res) => {
  const transaction = transactions.find(t => t.id === parseInt(req.params.id));
  if (!transaction) return res.status(404).send('Transaction not found.');

  const { type, category, amount, date, description } = req.body;
  transaction.type = type;
  transaction.category = category;
  transaction.amount = amount;
  transaction.date = date;
  transaction.description = description;

  res.json(transaction);
});

// DELETE /transactions/:id - Delete a transaction by ID
app.delete('/transactions/:id', (req, res) => {
  const transactionIndex = transactions.findIndex(t => t.id === parseInt(req.params.id));
  if (transactionIndex === -1) return res.status(404).send('Transaction not found.');

  transactions.splice(transactionIndex, 1);
  res.status(204).send();
});

// GET /summary - Get a summary of total income, expenses, and balance
app.get('/summary', (req, res) => {
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const balance = totalIncome - totalExpenses;

  res.json({ totalIncome, totalExpenses, balance });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
